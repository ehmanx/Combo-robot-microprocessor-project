/* 
 ADCSRA |= (1<<ADSC);		//Start ADC conversion
 
 ISR(ADC_vect){
	//Example of how to write interrupt code
	//Write interrupt code here
 }
 
 Check external or internal reference at:
 ADMUX AREF REFS0
 
*/
#ifndef ADC_DEFINE
#define ADC_DEFINE

#include <avr/interrupt.h>

//Starts the analog to digital conversion
void ADC_Start_Conversion();
//Setup ADC with interrupt enabled
void ADC_Initiate_Interrupt(uint8_t _ref__);
//Setup ADC without interrupt
void ADC_Initiate(uint8_t _ref__);
//Get the converted value as10-bit value
uint16_t ADC_Get_Value_10();
//Get the converted value as 8-bit value
uint8_t ADC_Get_Value_8();
//Get the converted value as signed 8-bit value
int8_t ADC_Get_Value_8s();

//Starts the analog to digital conversion
void ADC_Start_Conversion(){
	 ADCSRA |= (1<<ADSC);
}

//Interrupt Enabled ADC(Reference choice[0=ext/1=int])
void ADC_Initiate_Interrupt(uint8_t _ref__){
	ADCSRA |= (1<<ADPS2)|(1<<ADPS1)|(1<<ADPS0);		//prescaler set to 128
	ADMUX |= (1<<ADLAR);							//Left shift result
	if(_ref__ == 1) ADMUX |= (1<<REFS0);			//AVCC with external cap at AREF
	ADCSRA &= ~(1<<ADATE);							//Disable ADC Auto trigger
	ADCSRA |= (1<<ADIE);							//Interrupts Enabled
	ADCSRA |= (1<<ADEN);							//ADC Enable
	sei();											//enable global interrupt
	//ADCSRA |= (1<<ADSC);							//Start ADC conversion
}


//Non interrupt based ADC(Reference choice[0=int/1=ext])
void ADC_Initiate(uint8_t _ref__){
	ADCSRA |= (1<<ADPS2)|(1<<ADPS1)|(1<<ADPS0);		//prescaler set to 128
	ADMUX |= (1<<ADLAR);							//Left shift result
	ADMUX |= (1<<ADLAR);							//Left shift result
	if(_ref__ == 1) ADMUX |= (1<<REFS0);			//AVCC with external cap at AREF
	ADCSRA &= ~(1<<ADIE);							//Interrupts Disabled
	ADCSRA |= (1<<ADATE);							//ADC Auto trigger
	ADCSRA |= (1<<ADEN);							//ADC Enable
	//ADCSRA |= (1<<ADSC);							//Start ADC conversion
}

//Function to get ADC 10-bit values()
uint16_t ADC_Get_Value_10(){
	uint16_t _tempADC__= ADCL;			//read low byte first
	uint16_t _ADC_Value__ = (ADCH<<2);	//read high byte and shift it 8 steps
	_ADC_Value__ |= (_tempADC__>>6);	//Or low and high together
	return _ADC_Value__;				//Return value
}

//Function to get ADC 8-Bit values()
uint8_t ADC_Get_Value_8(){
	uint8_t _ADC_Value__ = ADCH;		//Read only high byte
	return _ADC_Value__;				//return value
}

//Function to get ADC 8-Bit signed values()
int8_t ADC_Get_Value_8s(){
	uint8_t _ADC_Value__ = ADCH;		//Read only high byte
	return _ADC_Value__;				//return value
}
#endif
