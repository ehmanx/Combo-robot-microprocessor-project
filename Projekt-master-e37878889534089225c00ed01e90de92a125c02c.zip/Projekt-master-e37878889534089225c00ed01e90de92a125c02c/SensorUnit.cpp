/*
 * SensorUnitMux.cpp
 * v1.12
 * Created: 2015-11-16 23:32:23
 *  Author: Junior
 */ 

#include "SENS_FUNC.h"

#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

#include "WALL.h"
#include "RGB.h"
#include "ADC.h"
#include "REFLEX.h"
#include "SPI_Master.h"

//Global variables and functions are in SENS_FUNC.h

int main(void){
	ADC_Initiate_Interrupt(0, 1);
	SPI_MasterInit();
	
	DDRB |= 0x0F;						//Set Analog MUX output
	DDRC |= (1<<PC6)|(1<<PC7);			//Outer sensor connected to double ir emitters
	LINE_ENABLE_DIRECTION |= 0x7F;
	
	LINE_ENABLR_PORT = 0;
	
	PORTC &= ~(0xC0);	//Turn of enable on 1,2,10,11 emmitors
	PORTC |= (1<<PC6);	//Turn on IR-Emmiter 1 and 11
	
	ADC_Start_Conversion();
    while(1){
		if(!gather_intel){
			Calculate_Average();
			//Sweep_RGB();
			Rflx_Calculate_To_Top();
			line_position = Rflx_Line_Calculation(line_sensor_start, line_sensor_amnt);
			Wall_Add_Value();
			Pack_Data();
 			Send_Calculated_Values();
			
			_delay_ms(5);
			gather_intel = 1;
			ADC_Start_Conversion();
		}
		_delay_ms(1);
    }
}

 ISR(ADC_vect){
	 /*
	if(first_conversion){
		sensor_values[sensor_cntr][current_data] = ADC_Get_Value_8(); //discard first conversion
		first_conversion = 0;
	}
	else{
		*/
	 switch (sensor_cntr){
		case 0:
		
		//sensor_values[sensor_cntr][current_data] = ADC_Get_Value_8();
		sensor_values[sensor_cntr][current_data] = 0;
		
		PORTC &= ~(0xC0);	//Turn of enable on all 2x2 emmitors
		PORTC |= (1<<PC7);
		sensor_cntr++;
		ADC_Initiate_Interrupt(0, 2);
		break;

		case 1:
		sensor_values[sensor_cntr][current_data] = ADC_Get_Value_8();
		PORTC &= ~(0xC0);	//Turn of enable on all 2x2 emitors
		sensor_cntr++;
		LINE_ENABLR_PORT = line_high;
		ADC_Initiate_Interrupt(0, 0);
		break;
		
		case 9:
		sensor_values[sensor_cntr][current_data] = ADC_Get_Value_8();
		PORTC &= ~(0xC0);	//Turn of enable on all 2x2 emitors
		PORTC |= (1<<PC6);
		ADC_Initiate_Interrupt(0, 4);
		sensor_cntr++;
		break;
		
		case 10:
		sensor_values[sensor_cntr][current_data] = ADC_Get_Value_8();
		PORTC &= ~(0xC0);	//Turn of enable on all 2x2 emitors
		ADC_Initiate_Interrupt(0, 0);
		sensor_cntr++;
		break;
		
		default:
			sensor_values[sensor_cntr][current_data] = ADC_Get_Value_8();
			//if(sensor_cntr == 0) sensor_values[sensor_cntr][current_data] += 80;	//disbles first ir on rflx
			sensor_cntr++;	//Increment to next sensor
			SENSOR_MUX_ADDR++;	//increment analog mux address
		
			if(sensor_cntr >= LINE_IR_START + LINE_IR_SENSOR_AMOUNT){	//check if  outside ir sensor bound
				line_high = 1;											//reset enable pointer to first ir
				LINE_ENABLR_PORT = 0;									//turn all ir sensors off
				PORTC &= ~(0xC0);										//Turn of enable on all 2x2 emmitors
				
			}
			else if(sensor_cntr > LINE_IR_START){						//Check if inside ir sensor bound
				line_high = (line_high<<1);								//Shift 1 to left
				LINE_ENABLR_PORT = line_high;							//Enable next ir
			}
			
			if(sensor_cntr == 8){
				PORTC &= ~(0xC0);
				PORTC |= (1<<PC7);
				ADC_Initiate_Interrupt(0, 3);
			}
			if(sensor_cntr >= TOT_AMOUNT_OF_SENSORS){					//check if counter reach max amount of sensors
				PORTC |= (1<<PC6);	//Turn on IR-Emmiter 1 and 11;
				gather_intel = 0;										//turn off re calculation of ADC
				sensor_cntr=0;											//Reset to first sensor		
				SENSOR_MUX_ADDR &= 0xF0;								//Set Mux address to 0
				//first_conversion = 1;									//Reset first conversion
				current_data++;											//inc data to next depth
				if(current_data >= AVERAGE_DATA_SIZE) current_data=0;	//Reset depth if over dimension level
			}
		break;
	}
	 
	if(gather_intel)ADC_Start_Conversion();						//Restart conversion if not finished with sweep
 }
 
 uint8_t BtnDebounce(){ //De-bounce function to handle de-bouncing on various buttons
	int delay_counter = 0;
	char btn_press_result = 0;
	_delay_ms(40);
	
	while(bit_is_set(PINC, PC7) && delay_counter < DEBOUNCE_DELAY+500){
		PORTB |= (1<<PB4);
		if (delay_counter >= DEBOUNCE_DELAY) btn_press_result = 1;
		_delay_ms(1);
		delay_counter++;
	}
	PORTB &= ~(1<<PB4);
	return btn_press_result;
}
 
 void Calculate_Average(){ //Function to get average values from raw data
	 uint16_t temp_store_[TOT_AMOUNT_OF_SENSORS];
	 for (int i=0; i<TOT_AMOUNT_OF_SENSORS; i++){
		 temp_store_[i]=0;
		 for (int j=0; j<AVERAGE_DATA_SIZE; j++){
			 temp_store_[i] += sensor_values[i][j];
		 }
		 if(i==7){
			temp_store_[i] = 0.75*temp_store_[i];
		 }
		 averaged_sensor_value[i] = temp_store_[i]/AVERAGE_DATA_SIZE;		 
	 }
 }
 
void Pack_Data(){ //Package all calculated sensor data
	uint8_t _rflx_cmd_ = 0;		//command data for reflex 0 = everything ok, 1 = finish detected, 2 = no line found, 
	
	if(Rflx_Check_Line_All()){
		if(Rflx_Check_Stopp()) _rflx_cmd_ = 1;
		else _rflx_cmd_ = 0;
	}
	
	else _rflx_cmd_ = 2;
	for (int i=0; i<OUTPUT_AMOUNT; i++){
		switch (i){
			case 0: calculated_sensor_values[i] = 0xFF;					//Header
			break;
			//case 1: calculated_sensor_values[i] = 16; //rgb_type;		//RGB Data
			//break;
			case 2: calculated_sensor_values[i] = _rflx_cmd_;			//Reflex Command
			break;
			case 3: calculated_sensor_values[i] = line_position;		//Reflex Data
			break;
			case 4: calculated_sensor_values[i] = Wall_Detect();		//Wall Command
			break;
			case 5: calculated_sensor_values[i] = Wall_Sensor_Calculate();		//Wall Data
			break;
			
			//case 6: _mult_ = 32; //Gyro
			//break;
			case 7: calculated_sensor_values[i] = averaged_sensor_value[14];	//Fram
			break;
			/*case 8: _mult_ = 25.6;											//Red
			break;
			case 9: calculated_sensor_values[i] = average_sensor_value[			//Green
			break;
			case 10: 															//Blue
			break;
		*/	case 11: calculated_sensor_values[i] = averaged_sensor_value[12];	//Vägg vänster bak
			break;
			case 12: calculated_sensor_values[i] = averaged_sensor_value[13];	//Vägg vänster fram
			break;
			case 13: calculated_sensor_values[i] = averaged_sensor_value[15];	//Vägg höger fram
			break;
			case 14: calculated_sensor_values[i] = averaged_sensor_value[16]; 	//Vägg höger bak
			break;
			default: calculated_sensor_values[i] = i;
		}
	}
}

void Send_Calculated_Values(){//Send Calculated data array through SPI
		for (int j=0; j < OUTPUT_AMOUNT; j++){
		SPI_MasterTransmit(calculated_sensor_values[j]);
	}
}

//Maps values in a defined range (value, min input, max input, min output, max output)
int16_t Map_Values(int16_t _x_, int16_t in_min, int16_t in_max, int16_t out_min, int16_t out_max){
	return (_x_ - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}