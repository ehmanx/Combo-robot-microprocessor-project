/*
	Created: 11/22/2015 1:46:31 PM
	Author: adaha287
	Funktioner för att köra med motorerna på roboten.
*/	

#include <stdlib.h>
#include <avr/io.h>

void motor_Init(void);
void forward2(int left_percent, int right_percent);
void rotate_left(int percent);
void rotate_right(int percent);




void forward2(int left_percent, int right_percent)
{
	int max = 255;
	
	if(left_percent > 100){
		left_percent = 100;
	}
	if (right_percent > 100)
	{
		right_percent = 100;
	}
	float to_left_percent = 0.01 * left_percent;
	float to_right_percent = 0.01 * right_percent;
	
	DDRD |= (1<<PD4)|(1<<PD5)|(1<<PD6)|(1<<PD7); // Set port 4-7 as outputs
	
	if(to_left_percent < 0){
		PORTD &= ~(1<<PD4);
		OCR2B  = (-to_left_percent*max); //Runs right motor at right_percent % of max backwards (X<30 wont work, to slow)
	}
	else{
		PORTD |= (1<<PD4);
		OCR2B  = (to_left_percent*max); //Runs left motor at left_percent % of max forward (X<30 wont work, to slow)
	}
	if(to_right_percent < 0){
		PORTD &= ~(1<<PD5);
		OCR2A  = -1*to_right_percent*max; //Runs right motor at right_percent % of max backwards (X<30 wont work, to slow)
	}
	else{
		PORTD |= (1<<PD5);
		OCR2A  = (to_right_percent*max); //Runs right motor at right_percent % of max forward (X<30 wont work, to slow)
	}
}
void motor_Init()
{
	TCCR2A |= (1<<COM2A1)|(0<<COM2A0); //Toggle OC2A on Compare Match
	TCCR2A |= (1<<COM2B1)|(0<<COM2B0); //Toggle OC2B on Compare Match
	
	TCCR2A |= (1<<WGM20); // Timer/Counter mode: Phase PWM
	TCCR2A &= ~(1<<WGM21); // Timer/Counter mode: Phase PWM
	
	TCCR2B &= ~(1<<WGM22); //Mode 3 - Fast PWM
	TCCR2B |= (0<<CS22)|(0<<CS21)|(1<<CS20); //Prescale none
	TCCR2B |= (0<<FOC2A)|(0<<FOC2B); //Force output till OC2A vid cmp A och till OC2B vid cmp B
	
	ASSR   |= (0<<EXCLK); //External clock???
	TIMSK2 |= (0<<OCIE2B)|(0<<OCIE2A); //Enable timer interrupt A/B??
	
}

void rotate_left(int percent)
{
	forward2(-percent, percent);
}

void rotate_right(int percent)
{
	forward2(percent, -percent);
}


